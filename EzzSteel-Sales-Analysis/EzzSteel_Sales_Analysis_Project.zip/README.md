# EzzSteel Sales Data Analysis

A beginner-friendly, end-to-end sales data analysis project built with Python (pandas, matplotlib, seaborn),
using real invoice-level sales data from a steel manufacturer (EzzSteel).

## Project files

| File | Description |
|---|---|
| `EzzSteel_Sales_Analysis.ipynb` | Main notebook: full analysis, cleaning steps, charts, and insights (run top to bottom) |
| `EzzSteel_Full_Dataset.xlsx` | Original raw data (multi-sheet workbook; `Sales_Transactions` sheet is used) |
| `data/Sales_Transactions_Cleaned.csv` | Cleaned dataset exported after Section 3 of the notebook |
| `charts/` | PNG exports of all 5 charts from the notebook |

## What this project covers

1. Loading and inspecting a real, messy sales dataset (missing values, duplicates, mixed date formats,
   unit mix-ups, text-formatted numbers, inconsistent category labels).
2. Documented data cleaning with reasoning for every fix.
3. Feature engineering (Year / Month / Month Name, in chronological order).
4. Business analysis: total sales, category performance, best-selling products (by revenue and by
   quantity), regional performance, and monthly trends.
5. Five charts: sales by category, sales over time, top 10 products, sales by region, and domestic vs.
   export split.
6. Five data-driven business insights and a final summary.

## Key results

- **Total Sales:** ~49.5 billion EGP across 2,378 cleaned invoices (2020–2023)
- **Best category:** Long Steel (~61% of revenue)
- **Top region:** Egypt (domestic), ~34.5 billion EGP
- **Best-selling product (by revenue):** Steel grade B500C
- **Growth:** Annual sales nearly tripled from 2020 to 2023 (+195%)

## Note on "Profit"

The `Sales_Transactions` sheet has no cost data, so profit cannot be calculated per invoice, product,
category, or region. A company-wide Net Profit figure exists in a separate `Monthly_Financial` sheet, but
it's a consolidated total for the whole business (not just these tracked sales) and is reported in the
notebook only as background context — not as a metric derived from this sales dataset.

## How to run

```bash
pip install pandas numpy matplotlib seaborn openpyxl
jupyter notebook EzzSteel_Sales_Analysis.ipynb
```
